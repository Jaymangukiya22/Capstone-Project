import React from 'react';
import QuizResults from '@/components/student/QuizResults';

const QuizResultsPage: React.FC = () => {
  return <QuizResults />;
};

export default QuizResultsPage;
