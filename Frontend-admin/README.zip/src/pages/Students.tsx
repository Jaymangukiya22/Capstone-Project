import { StudentQuizContent } from '@/components/student/StudentQuizContent'

export function Students() {
  return <StudentQuizContent />
}
