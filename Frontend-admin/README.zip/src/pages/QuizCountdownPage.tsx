import React from 'react';
import QuizCountdown from '@/components/student/QuizCountdown';

const QuizCountdownPage: React.FC = () => {
  return <QuizCountdown />;
};

export default QuizCountdownPage;
