/// <reference types="vitest/config" />
import path from "path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: '0.0.0.0', // Necessary for Docker
    port: 5173,
    allowedHosts: ['.dpdns.org'],
    hmr: {
      // Cloudflare tunnel configuration
      // HMR will work through the tunnel
      host: 'quizdash.dpdns.org',
      clientPort: 443,
      protocol: 'wss'
    }
  },
  assetsInclude: ['**/*.html'],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src")
    }
  }
});