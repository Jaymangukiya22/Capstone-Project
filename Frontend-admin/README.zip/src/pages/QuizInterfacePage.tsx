import React from 'react';
import QuizInterface from '@/components/student/QuizInterface';

const QuizInterfacePage: React.FC = () => {
  return <QuizInterface />;
};

export default QuizInterfacePage;
